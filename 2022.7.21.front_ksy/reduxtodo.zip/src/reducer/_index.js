/* 
index로 적게되면 폴더까지만 경로로 가지와도 기본 경로로 읽습니다. import from /reducer
_index 읽지 못해서  import from /reducer/_index
*/

import { combineReducers } from "redux";
import todo from "./todo";

const rootReducer = combineReducers({
    todo,
});
export default rootReducer;
