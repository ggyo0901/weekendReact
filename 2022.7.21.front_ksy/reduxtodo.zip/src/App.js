import "./App.css";
import Todo from "./pages/todo";

function App() {
    return <Todo />;
}
export default App;
